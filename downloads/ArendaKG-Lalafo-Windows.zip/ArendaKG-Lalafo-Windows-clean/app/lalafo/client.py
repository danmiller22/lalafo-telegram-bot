from __future__ import annotations

import asyncio
import logging
import re
import uuid
from typing import Any
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

import httpx

from app.config import LALAFO_DISTRICT_FILTERS
from app.lalafo.parser import parse_detail_data, parse_search_data

logger = logging.getLogger(__name__)


class LalafoError(RuntimeError):
    pass


class LalafoAccessError(LalafoError):
    pass


class LalafoNotFound(LalafoError):
    pass


class LalafoClient:
    def __init__(
        self,
        *,
        timeout: float = 25.0,
        max_retries: int = 3,
        proxy_url: str = "",
    ) -> None:
        self.max_retries = max_retries
        self._user_hash = str(uuid.uuid4())
        self._timeout = timeout
        self._proxy_urls = [
            value.strip()
            for value in re.split(r"[,\n]+", proxy_url)
            if value.strip()
        ]
        self._proxy_index = 0
        self._headers = {
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140 Safari/537.36"
            ),
            "Accept-Language": "ru-RU,ru;q=0.9,en;q=0.7",
            "Accept": "text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8",
            # Required request context used by Lalafo's own web client.
            "device": "pc",
            "language": "ru_RU",
            "country-id": "12",
            "user-hash": self._user_hash,
            "content-type": "application/json",
            "X-Cache-Bypass": "yes",
            "Origin": "https://lalafo.kg",
            "Referer": "https://lalafo.kg/",
            "sec-ch-ua": '"Chromium";v="140", "Not=A?Brand";v="24"',
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": '"Windows"',
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "same-origin",
            "x-requested-with": "XMLHttpRequest",
        }
        self._client = self._make_client()

    def _make_client(self) -> httpx.AsyncClient:
        proxy_url = self._proxy_urls[self._proxy_index] if self._proxy_urls else None
        return httpx.AsyncClient(
            follow_redirects=True,
            timeout=httpx.Timeout(self._timeout),
            proxy=proxy_url,
            headers=self._headers,
        )

    async def _rotate_proxy(self) -> None:
        if len(self._proxy_urls) < 2:
            return
        await self._client.aclose()
        self._proxy_index = (self._proxy_index + 1) % len(self._proxy_urls)
        self._client = self._make_client()
        logger.warning("Rotated to another verified Lalafo proxy")

    async def _use_direct_connection(self) -> None:
        if not self._proxy_urls:
            return
        await self._client.aclose()
        self._proxy_urls = []
        self._proxy_index = 0
        self._client = self._make_client()
        logger.warning("Lalafo proxy failed; retrying through direct connection")

    async def __aenter__(self) -> "LalafoClient":
        return self

    async def __aexit__(self, *_: object) -> None:
        await self.close()

    async def close(self) -> None:
        await self._client.aclose()

    async def _get_json_via_relay(self, url: str) -> dict[str, Any] | None:
        """Use an HTTPS relay when Lalafo blocks the cloud egress address."""
        relay_url = "https://r.jina.ai/http://" + url.removeprefix("https://")
        try:
            async with httpx.AsyncClient(
                timeout=httpx.Timeout(min(self._timeout, 20.0)),
                follow_redirects=True,
                headers={"Accept": "application/json", "User-Agent": self._headers["User-Agent"]},
            ) as relay:
                response = await relay.get(relay_url)
                if response.status_code != 200:
                    return None
                payload = response.json()
                return payload if isinstance(payload, dict) else None
        except (httpx.HTTPError, ValueError):
            logger.warning("Lalafo HTTPS relay failed", exc_info=True)
            return None

    async def _get_json(self, url: str) -> dict[str, Any]:
        last_error: Exception | None = None
        for attempt in range(self.max_retries + 2):
            try:
                response = await self._client.get(
                    url, headers={"request-id": str(uuid.uuid4())}
                )
                if response.status_code in (403, 429):
                    if attempt >= self.max_retries:
                        if self._proxy_urls:
                            await self._use_direct_connection()
                            continue
                        relayed = await self._get_json_via_relay(url)
                        if relayed is not None:
                            logger.warning("Loaded Lalafo JSON through HTTPS relay")
                            return relayed
                        raise LalafoAccessError(
                            f"Lalafo returned HTTP {response.status_code}; access was not bypassed"
                        )
                    retry_after = float(response.headers.get("Retry-After", 0) or 0)
                    if attempt >= self.max_retries and self._proxy_urls:
                        await self._use_direct_connection()
                        continue
                    await self._rotate_proxy()
                    await asyncio.sleep(max(retry_after, 2**attempt))
                    continue
                if response.status_code in (404, 410):
                    raise LalafoNotFound("Lalafo advertisement is unavailable")
                if response.status_code >= 500:
                    raise httpx.HTTPStatusError(
                        "Temporary Lalafo error", request=response.request, response=response
                    )
                response.raise_for_status()
                payload = response.json()
                if not isinstance(payload, dict):
                    raise LalafoError("Lalafo JSON response is not an object")
                return payload
            except LalafoNotFound:
                raise
            except LalafoAccessError:
                raise
            except (httpx.TransportError, httpx.HTTPStatusError) as exc:
                last_error = exc
                if attempt >= self.max_retries:
                    if self._proxy_urls:
                        await self._use_direct_connection()
                        continue
                    break
                if attempt >= self.max_retries and self._proxy_urls:
                    await self._use_direct_connection()
                    continue
                await self._rotate_proxy()
                await asyncio.sleep(2**attempt)
        raise LalafoError(f"Lalafo request failed after retries: {type(last_error).__name__}")

    async def _get_text(self, url: str) -> str:
        last_error: Exception | None = None
        for attempt in range(self.max_retries + 2):
            try:
                response = await self._client.get(
                    url,
                    headers={
                        "request-id": str(uuid.uuid4()),
                        "Accept": "text/html,application/xhtml+xml",
                    },
                )
                if response.status_code in (403, 429):
                    if attempt >= self.max_retries:
                        raise LalafoAccessError(
                            f"Lalafo returned HTTP {response.status_code}; access was not bypassed"
                        )
                    retry_after = float(response.headers.get("Retry-After", 0) or 0)
                    await self._rotate_proxy()
                    await asyncio.sleep(max(retry_after, 2**attempt))
                    continue
                if response.status_code in (404, 410):
                    raise LalafoNotFound("Lalafo advertisement is unavailable")
                if response.status_code >= 500:
                    raise httpx.HTTPStatusError(
                        "Temporary Lalafo error", request=response.request, response=response
                    )
                response.raise_for_status()
                return response.text
            except (LalafoNotFound, LalafoAccessError):
                raise
            except (httpx.TransportError, httpx.HTTPStatusError) as exc:
                last_error = exc
                if attempt >= self.max_retries:
                    break
                await self._rotate_proxy()
                await asyncio.sleep(2**attempt)
        raise LalafoError(f"Lalafo request failed after retries: {type(last_error).__name__}")

    @staticmethod
    def _search_params(
        search_url: str, page: int, offerer: str | None = None
    ) -> list[tuple[str, str]]:
        """Translate the configured human URL to Lalafo's public feed filters."""
        parts = urlsplit(search_url)
        path_parts = {part for part in parts.path.split("/") if part}
        room_ids = {
            "studio": "15496",
            "1-bedroom": "2773",
            "2-bedrooms": "2774",
        }
        params: list[tuple[str, str]] = [
            ("expand", "url"),
            ("per-page", "20"),
            ("category_id", "2044"),
            ("page", str(page)),
            ("city_id", "103184"),
        ]
        for index, (_, value) in enumerate(
            (item for item in room_ids.items() if item[0] in path_parts)
        ):
            params.append((f"parameters[69][{index}]", value))
        district_ids = [
            district_id
            for alias, district_id in LALAFO_DISTRICT_FILTERS
            if alias in path_parts
        ]
        for index, district_id in enumerate(district_ids):
            params.append((f"parameters[357][{index}]", district_id))
        if "bez-podseleniya" in path_parts:
            params.append(("parameters[946][0]", "81537"))
        if offerer == "owner":
            params.append(("parameters[2149][0]", "19057"))
        elif offerer == "realtor":
            params.append(("parameters[2149][0]", "42340"))
        else:
            offerer_index = 0
            if "owner" in path_parts:
                params.append((f"parameters[2149][{offerer_index}]", "19057"))
                offerer_index += 1
            if "real-estate-agency" in path_parts:
                params.append((f"parameters[2149][{offerer_index}]", "42340"))
        for key, value in parse_qsl(parts.query, keep_blank_values=True):
            if key in {"price[from]", "price[to]", "currency", "sort_by"}:
                params.append((key, value))
        params.append(("with_feed_banner", "true"))
        return params

    async def search(
        self, search_url: str, page: int = 1, offerer: str | None = None
    ):
        parts = urlsplit(search_url)
        search_params = self._search_params(search_url, page, offerer)
        api_url = urlunsplit(
            (
                parts.scheme,
                parts.netloc,
                "/api/search/v3/feed/search",
                urlencode(search_params),
                "",
            )
        )
        try:
            data = await self._get_json(api_url)
        except LalafoAccessError:
            compact_params = [
                (key, value)
                for key, value in search_params
                if not key.startswith("parameters[357][")
            ]
            if len(compact_params) == len(search_params):
                raise
            logger.warning(
                "Lalafo rejected the long district-filter request; retrying the same "
                "Bishkek room and price search without district query parameters"
            )
            compact_api_url = urlunsplit(
                (
                    parts.scheme,
                    parts.netloc,
                    "/api/search/v3/feed/search",
                    urlencode(compact_params),
                    "",
                )
            )
            data = await self._get_json(compact_api_url)
        return parse_search_data(data, base_url=f"{parts.scheme}://{parts.netloc}")

    async def detail(self, detail_url: str):
        match = re.search(r"-id-(\d+)(?:$|[/?#])", detail_url)
        if not match:
            raise LalafoError("Lalafo detail URL has no advertisement id")
        expected_id = int(match.group(1))
        parts = urlsplit(detail_url)
        api_url = urlunsplit(
            (
                parts.scheme,
                parts.netloc,
                f"/api/search/v3/feed/details/{expected_id}",
                "expand=url",
                "",
            )
        )
        payload = await self._get_json(api_url)
        ad = parse_detail_data(payload, source_url=detail_url)
        if ad.lalafo_id != expected_id:
            raise LalafoError(
                f"Lalafo detail mismatch: expected {expected_id}, received {ad.lalafo_id}"
            )
        return ad
