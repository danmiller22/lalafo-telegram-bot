"""Aiogram payment bot package."""
