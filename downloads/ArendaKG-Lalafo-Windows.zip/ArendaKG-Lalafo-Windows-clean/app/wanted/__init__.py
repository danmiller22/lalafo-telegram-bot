"""Paid apartment wanted ads."""
